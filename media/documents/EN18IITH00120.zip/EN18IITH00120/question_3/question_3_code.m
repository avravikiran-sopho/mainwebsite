train_x = csvread('train.csv',1,1,[1,1,120,4]);
train_y = csvread('train.csv',1,5);
test_x = csvread('test.csv',1,1,[1,1,30,4]);
test_y = csvread('test.csv',1,5);
%model = fitcknn(train_,train_y);
model = fitcknn(train_x,train_y,'NumNeighbors',4);
training_loss = resubLoss(model);
predicted = predict(model,test_x);
%disp(training_loss);
count = 0;
for i = 1:30
   if(predicted(i) ~= test_y(i))
       count = count + 1;
   end
end
accuracy = (1 - (count/30))*100 ;
%accuracy on test data
disp(accuracy);

%Result is 93.33%















