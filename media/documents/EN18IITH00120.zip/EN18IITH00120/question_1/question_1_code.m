[funky, f] = audioread('qn1.wav');

fNorm = 70 / (f/2);
[b, a] = butter(2, fNorm, 'high');
funkyHigh = filtfilt(b, a, funky);
freqz(b,a,128,f);
audiowrite('qn1_output.wav',funkyHigh,f);
%sound(funkyHigh,f)

