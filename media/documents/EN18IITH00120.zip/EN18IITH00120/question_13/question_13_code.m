syms x
numerator = 3*x^2 + 4*x -1;
denominator = 2*x^2 + 4;
f = numerator/denominator;
fplot(f)
figure;
limit(f,inf); % horizontal asymptotes
disp(limit(f,inf))

crit_pts = solve(simplify(diff(f)));

disp(crit_pts) % absolute minima and maxima
hold on
fplot(f)
plot(double(crit_pts), double(subs(f,crit_pts)),'ro')
title('Maximum and Minimum of f')
text(-1,0,'Local minimum')
text(3.5,4.5,'Local maximum')
hold off


f1 = diff(f);
f2 = diff(f1);
inflec_pt = solve(f2,'MaxDegree',3);
double(inflec_pt)
inflec_pt = inflec_pt(1);
figure;
fplot(f, [-5 10])

hold on
plot(double(inflec_pt), double(subs(f,inflec_pt)),'ro')
title('Inflection Point of f')
text(6,6.5,'Inflection point')
hold off
