image_read = imread('qn11.jpg');
image_complement = imcomplement(image_read);
filter = fspecial('gaussian',7,10);
final = imfilter(image_complement,filter);
imshowpair(image_read,final,'montage');
%imshow(final,'InitialMagnification',100)
%hgsave(final,'qn.jpg')