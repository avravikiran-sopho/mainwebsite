x = csvread('qn10_input.csv');
y = csvread('qn10_output.csv');
size_x = size(x);
r = ones(10000,1);
final_matrix = [x r];
m = linsolve(final_matrix,y);
disp(m)



% results 
% m value is 2.7514
% c value is 50.7826
