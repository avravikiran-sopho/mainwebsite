syms y(x)
ode = diff(y,x)+y/(x*log(x)) == 2;
ySol(x) = dsolve(ode);
disp(ySol(x))

% answer
% C1/log(x) + (2*x*(log(x) - 1))/log(x)
%from given conditions C1 is 2
% y = 2/log(x) + (2*x*(log(x) - 1))/log(x)