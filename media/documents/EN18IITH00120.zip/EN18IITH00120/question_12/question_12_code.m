fun = @(x) (-x)+4*sqrt(-x);
q = integral(fun,-4,0);
disp(q)
fun1 = @(x) (-x)+4*sqrt(x);
q2 = integral(fun1,0,16);
disp(q2)

qf = q+q2;
disp(qf)

% result: total area(qf) is 72 