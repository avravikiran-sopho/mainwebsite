x = [2.334;4.566;8.366;12;10.65];
y = [2.86;12;14;10;2.34];
%intialize area to ones
area = ones(5,1);
for i=0:4
    a = [x(mod(i,5)+1),x(mod(i+2,5)+1),x(mod(i+3,5)+1)];
    b = [y(mod(i,5)+1),y(mod(i+2,5)+1),y(mod(i+3,5)+1)];
    area(i+1) = polyarea(a,b);
end
%Compute all areas formed and take max of all
disp(max(area))

%Result is 47.8884

    
    
