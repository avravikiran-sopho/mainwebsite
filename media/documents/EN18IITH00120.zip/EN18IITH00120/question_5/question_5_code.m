syms x y z
e1 = x-2*y+3*z==7 ;
e2 = 2*x+y+z==4;
e3 = -3*x+2*y-2*z==-10;
[A,B] = equationsToMatrix([e1, e2, e3], [x, y, z]);
X = linsolve(A,B);
disp(X)

% result X is [2 -1 1]
