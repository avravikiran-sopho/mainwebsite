%the given equation can be represented as matrix form as below where H and
%f are matrix and vector respectively
% matrix notation is f(x) = 1/2*x^t*H*x + f^T*x
% with H and f as below
H = [1 -1;-1 2];
f = [-2;-6];
A = [1 1; -1 2; 2 1];
b = [2; 2; 3];
lb = zeros(2,1);

options  = optimoptions('quadprog',... 
'Algorithm','interior-point-convex','Display','off');
[x,fval,exitflag,output,lambda] = ... 
quadprog(H,f,A,b,[],[],lb,[],[],options);


disp(x); % x value i.e; x1 and x2
% result obtained is x1=0.6667 x2=1.3333
disp(fval); % functional value when it is minimum
%fval is -8.2222
disp(exitflag);% exit flag indicates that it is local minimum
% exit flag is 1