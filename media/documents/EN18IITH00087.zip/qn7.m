phi = y;
syms y(t) u;
deqn = diff(y,t,2) == -10*sin(y) - 2*diff(y,t) + u;
x = laplace(deqn);
disp(x);
