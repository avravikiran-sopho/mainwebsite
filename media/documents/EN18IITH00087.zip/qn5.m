function qn5 (x, y, z)

eqn1 = x - 2*y + 3*z == 7;
eqn2 = 2*x + y + z == 4;
eqn3 = -3*x + 2*y - 2*z == -10;
solution = solve([eqn1, eqn2, eqn3], [x, y, z]);
x = solution.x;
y = solution.y;
z = solution.z;
disp = 'x = ';
display(x);
disp = 'y = ';
display(y);
disp = 'z = ';
display(z);
end