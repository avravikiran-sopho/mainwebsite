syms y(x);

deqn = x*log(x)*diff(y,x) + y == 2*x*log(x);
Sol(x) = dsolve(deqn);
disp (Sol(x));
