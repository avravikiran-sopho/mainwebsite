function Fd = untitled

Fs = 44100;  

Fstop = 60;          % Stopband Frequency
Fpass = 70;          % Passband Frequency
Astop = 80;          % Stopband Attenuation (dB)
Apass = 1;           % Passband Ripple (dB)
match = 'passband';  % Band to match exactly


h  = fdesign.highpass(Fstop, Fpass, Astop, Apass, Fs);
Fd = design(h, 'butter', 'MatchExactly', match);
[x,Fs] = audioread('qn1.wav');
f=filter(Fd,x);
audiowrite('qn1.wav',f,Fs);
Y = fft(f);
L=length(f);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
F = Fs*(0:(L/2))/L;
plot(F,P1)
end



